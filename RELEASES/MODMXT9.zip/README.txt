Rev History:

29/05/19 
- Vibrato Corrected.
- You can increase / Decrease the frequency in the output device with the Left and Right keys
- You can activate/Desactivate Autoinit DMA with Space
-> No more Mouse needed if your BLASTER env variable is correct
- Mixing Code SpeedUp : 16% faster on 8086 (Mix 2 Samples at the same time)
- No more supported output device no more highlighted in the output device menu

18/06/19
- Now use 5 Buffers for the mixing
- Use the /C command to display the cursor (Used by some mouse drivers)
- Correction in FAR and ULT Loaders for less crash.
- Reduced the number of file supported in a folder to 255 (10Kb of memory saved)
- Modules volume now saved correctly and programs can be loaded.
- You can change the frequency for each module (With Left/Right)

12/07/19
- Gravis Ultrasound support added back, and working on 8088 machines !
- Corrected the Pattern Jump effect.
- Covox I/O port no more Hardcoded, and optimized.

16/07/19
- Corrected a Key Off bug in S3M
- Added BlasterBoard detection (Trial)
- Increase the Max Frequency to 48KHz (For BlasterBoard test only)

19/07/19
- BlasterBoard detection Ok.
- Max Frequency for BlaserBoard : 62KHz
- Correct the Sound Blaster env variable Read
- Correct the Gravis Ultrasound Volume (Used 33 values instead of 65)
- Music notes no more displayed out of the screen (Sample display mode)
- Various display bug and french text removed.
- Improve mixing speed (Again) +5% for 4 Channels MOD.

24/07/19
- Corrected the notes frequency calculation. ( The notes changed with the mixing frequency)
- change the File open function parameters. (File open sometimes bug)

30/07/19
- Stereo replay is back
- Improved samples increment precision
- Pattern not used are not loaded in .MOD Files

Hi,

I release this pre version (3nd) of Mod Master 2.2 XT for Test

It is a "Downgraded" and Optimized version of Mod Master 2.2

I keep the Mod Master 2.2 Doc inside for reference.

Output devices supported:
- Covox at 0388h (Hardcoded for the moment)
- Sound Blaster Auto initializes DMA - Mono Up to 45KHz
(Tested on Sound Galaxy NX 2, Sound Blaster 2.0, Sound Blaster Pro 2, DosBox)
- Gravis UltraSound

I removed all the other sound output support for the moment.

Warning : A Mouse is mandatory to configure the Output frequency.
          The Sound Blaster is detected by the BLASTER Env Variable.

- Why I did it ?
I started a retro computer last year.
After seing 8086 Corruption and discovered GLX Player (Yes, I did not know it before), I decided to test My First Mod Master on a PC XT.
Using a 4 Channel module, on an Amstrad PC1640 (8086 8MHz)
- Mod Master 1 is working at 4KHz. (PC Speaker)
- Mod Master 2.0 working at 8KHz. (Sound Blaster)

Then I teted GLX and I was of course surprized by its speed !

Looking back into the code, I saw the horrible Mod Master 1 and 2 mixing code, and the quite nice Mod Master 2.2 Code...

- How I did it ?
I decided to downgrade the Mod Master 2.2 code.
The more complicated part was the VGA Interface to downgrade to CGA.

First test gave me a lower overall performance than GLX Player, but close anyway.

After some optimization and the add of 4 Mixing buffer (2 were used before), the result was far better.
My goal was to be close to GLX, but also to try to keep a good mixing and replay quality.

GLX still has a faster Mixing code.
Mod master have some things added that makes it play modules at an higher frequency without noticable sound glitch (Crack)

I have no idea how GLX is working (Almost like my player I beleave as the performance is similar) 
I simply do it in "My Way"

I also don't see this as a performance, as it is now REALLY easyer to code, 
with modern text editor and 4 PC running in the same machine under DOSBOX.
Currenty, we can play a module under FT2, Mod Master and see a video of an amiga playing the same module in Youtube.
This save hours and hours of work.

If you want to discover Mod Master "Secret": Press F6 to go to the debug mode display.

Some last words: 
There is a value displayed "Max Mixed" this show the number of channels mixed for the current buffer before it is "Too Slow".
Then, this value does not show the "Real" max.

Thanks to Carlo Vogelsang for Galaxy Player, It did show me it was possible to have great sound on XT.
Thanks to Trixter for supporting me and for Bug Reports.

FreddyV