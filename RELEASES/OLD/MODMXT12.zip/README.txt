Hi,

Mod Master 2.2 XT Test Release 10

It is a "Downgraded" and Optimized version of Mod Master 2.2

I keep the Mod Master 2.2 Doc inside for reference. (Modified for Mod Master XT)

Output devices supported:
- PC Speaker
- Covox
- Sound Blaster Auto initializes DMA - Mono Up to 45KHz
 (Tested on Sound Galaxy NX 2, Sound Blaster 2.0, Sound Blaster Pro 2, DosBox)
- Sound Blaster Pro Stereo
 (Tested on a Sound Blaster Pro 2.0, DosBox)
- Gravis UltraSound (Yes, even on XT Computer !)

I removed all the other sound output support for the moment.

Some advices:
- Delete MODM.CFG in case of problem to reset to the default values.


- Why I did it ?
----------------

I started a Retro computers collection in 2018 and I purchased again my First PC (An Amstrad PC1640)

After seing 8086 Corruption and discovered GLX Player (Yes, I did not know it before), I decided to test My First Mod Master on the PC1640.
Using a 4 Channel module, on an Amstrad PC1640 (8086 8MHz)
- Mod Master 1 is working at 4KHz. (PC Speaker)
- Mod Master 2.0 working at 8KHz. (Sound Blaster)

Then I teted GLX and I was of course surprized by its speed !

Looking back into the code, I saw the horrible Mod Master 1 and 2 mixing code, and the quite nice Mod Master 2.2 Code...

- How I did it ?
----------------

I decided to downgrade the Mod Master 2.2 code.

The more complicated part was the VGA Interface to downgrade to CGA.

First test gave me a lower overall performance than GLX Player, but close anyway.

After some optimization and the add of 4 Mixing buffer (2 were used before), the result was far better.
My goal was to be close to GLX, but also to try to keep a good mixing and replay quality.

My mixing code is a little slower than GLX one, but GLX use some trick that reduce the sound quality.
I also do not clean the buffer at the begining. The first mixed channel use a MOV, instead of an ADD, 
This now make Mod Master faster than GLX with 4 Channels .MOD (Probably not 8) with a better sound quality.
The Stereo replay code is also faster.

Thanks to Carlo Vogelsang for Galaxy Player, It did show me it was possible to have great sound on XT.
Thanks to Trixter for supporting me and for Bug Reports.

Projects for the Future:
- Put Back the Adlib code, for S3M ans SAT
- Implement Other Adlib File Format
- Add Mono

FreddyV

Known Bug / Not complete:
-------------------------
- Exotic file formats (MTM, S3M, FAR...) replay is not correct.
- The Samples replay is stoped when volume is 0. (Sound Blaster)
- .XM Volume commands, multiple sample instruments and instruments envelop not supported.
- If we load the Controle.S3M (Dune/Orange) With the GUS, samples loading is bugged after this.

Rev History:

29/05/19 
- Vibrato Corrected.
- You can increase / Decrease the frequency in the output device with the Left and Right keys
- You can activate/Desactivate Autoinit DMA with Space
-> No more Mouse needed if your BLASTER env variable is correct
- Mixing Code SpeedUp : 16% faster on 8086 (Mix 2 Samples at the same time)
- No more supported output device no more highlighted in the output device menu

18/06/19
- Now use 5 Buffers for the mixing
- Use the /C command to display the cursor (Used by some mouse drivers)
- Correction in FAR and ULT Loaders for less crash.
- Reduced the number of file supported in a folder to 255 (10Kb of memory saved)
- Modules volume now saved correctly and programs can be loaded.
- You can change the frequency for each module (With Left/Right)

12/07/19
- Gravis Ultrasound support added back, and working on 8088 machines !
- Corrected the Pattern Jump effect.
- Covox I/O port no more Hardcoded, and optimized.

16/07/19
- Corrected a Key Off bug in S3M
- Added BlasterBoard detection (Trial)
- Increase the Max Frequency to 48KHz (For BlasterBoard test only)

19/07/19
- BlasterBoard detection Ok.
- Max Frequency for BlaserBoard : 62KHz
- Correct the Sound Blaster env variable Read
- Correct the Gravis Ultrasound Volume (Used 33 values instead of 65)
- Music notes no more displayed out of the screen (Sample display mode)
- Various display bug and french text removed.
- Improve mixing speed (Again) +5% for 4 Channels MOD. (Now Mod MAster is Faster than GLX for 4 Channels)

24/07/19
- Corrected the notes frequency calculation. (The notes changed with the mixing frequency)
- Change the File open function parameters. (File open sometimes bug)

30/07/19 - Beta 9
- Stereo replay is back (Faster than GLX)
- Improved samples increment precision (Trixter)
- Pattern not used are not loaded in .MOD Files

20/09/19
- Now work with Hercule (With some bugs) use the /H command line parameter to activate.
- Covox output working again, Set the Mixing speed to a correct value ! 
  (Be carefull about the Files individual frequency)
- PC Speaker support is Back (And Much Faster)
- The Volume channel is no more used for .MOD Files (Pattern size reduced)
- Now use the Note instead of Period in the internal patterns (Pattern size reduced as well)
- Module time calculation removed, it takes really too many time on 8086 and it was finally useless as not correct :-)
- Small Mixing performance increase. (Buffer Signed to Unsigned conversion optimized)
- Up to 6 Octaves for .MOD Files, with default at 6.(Alvaro84, EHA-CH07.MOD)
- Arpeggio is Back and Corrected for LIVE.MOD (Trixter)
- Tested to work with DOPE.MOD, if the machine has 640Kb + UMB
- .MOD Files with Samples >64Kb are now loaded correctly (And Played on GUS) (DevanWolf, BINARY.MOD)
- .S3M Files With 16Bit Samples are now Loaded correctly (DevanWolf)
- '3CHN' .MOD Files loading Corrected (DevanWolf, 3CHN-C64.MOD)
- Tandy DAC Detection Added
- Display Screen added to show Up to 14 Channels (Press F4)
- .MTM Pattern loading Corrected
- Note Delay was no more working (Corrected)
- Custom DAC Added (Put the Custom DAC @ in the command line)

10/10/19 Beta 11
- Fast Tracker 2 support Added. (.XM, Beta)
  -> No Volume effect, Instrument envelop, multiple sample instr
- Monotone Support Added, PC Speaker. (.MON)
- Pause in Stereo Corrected.
- GSLINGER.MOD Does not crash anymore.
- Added the Effect name and Left/Right display in the multi channel display. (F3)
- Some minor bug Corrected.
- .S3M Files loading Speed increased. (Faster Pattern Unpack)
- GUS Samples Loading Speed increased.
 -> 2ND_PM.S3M Loads in 24s instead of 40s on a 8088 8MHz
 
24/11/19 Beta 12
 - Corrected a .MOD File loading problem (Sequence With patterns=255)
 - Increased the UMB Block numbers from 16 to 64. (Memory)
 - 16Bit samples loading corrected.
 - .MOD, S3M and XM Files Pattern compressed: Loading DOPE.MOD Patterns is no more a problem
  -> Partition decoding is much faster.
 - Lot of .XM Files Loading bug corrected and Extra Fine portamento Up/Down Added
 - Added the Free DOS Memory size on the Option Menu.
 